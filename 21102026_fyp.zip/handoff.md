# FinTrust-RAG: Complete Technical Handoff & Developer Guide

Welcome to the **FinTrust-RAG** codebase. This document serves as the comprehensive technical handoff for teammates working on **Financial RAG Robustness Under Evidence Noise** on the **TAT-QA** financial benchmark.

It details the full system architecture, both **Person A** (Retrieval & Indexing) and **Person B** (Evidence Tagging, Program Synthesis, Verification, Noise Injection, and Degradation Analysis), code contracts, file layout, experimental records, and execution instructions.

---

## 1. Executive Summary & Project Status

### What is Completed & Fully Integrated

1. **Retriever & Corpus Pipeline (Person A)**:
   - Deterministic passage builder (`src/passage_builder.py`) for text paragraphs (`<doc_id>::p<order>`) and linearized table rows (`<doc_id>::r<row_idx>`).
   - Table-aware indexing context (`paragraph_context="table_labels"`), enriching paragraphs with table headers and row labels.
   - Lexical retrieval (`BM25Okapi` with whole-number financial tokenization) and dense Contriever reranker (`BM25ContrieverRetriever`) with disk embedding caching.
   - Evidence-slot reservation rule (`reserve_paragraph_slots=4`) guaranteeing 4 paragraph slots and 1 table-row slot in top-5 retrieved evidence.
   - Strict and condensed retrieval metrics (`src/evaluate.py`).

2. **Downstream QA & Reasoning Pipeline (Person B)**:
   - **Evidence Tagger** (`src/evidence_tagger.py`): Rule-based extraction of currencies (`$100M`), percentages (`2.5%`), negative parenthetical numbers (`(114.2)`), years, scales (`thousand`, `million`, `billion`, `percent`), and passage provenance tracking.
   - **Program Synthesizer** (`src/program_synthesizer.py`): Maps question intent and operands to executable programs: `lookup()`, `add()`, `sub()`, `ratio()`, `yoy()`, `average()`, and `count()`. Automatically filters non-pertinent year metadata and extracts citation IDs.
   - **Verifier** (`src/verifier.py`): 3-stage validation:
     1. *Pointer Validity*: Every operand must be grounded in retrieved evidence.
     2. *Unit Consistency*: Forbids mixing currencies and percentages in arithmetic operations.
     3. *Reasonableness / Sanity*: Ensures denominators are non-zero, outputs are finite, and values conform to financial magnitudes.
   - **Execution Engine** (`src/pipeline.py:_compute`): Evaluates verified programs, infers answer scale, and formats numerical results.

3. **Noise Injection Engine (Person B - Day 5)**:
   - Systematic injection of 3 noise types across 4 severity levels (`src/inject_noise.py`):
     - **Conflicting Information** (`conflict`): Perturbs numbers in retrieved passages by ±10% to ±40% or injects revised interim financial disclosures.
     - **Redundancy** (`redundancy`): Injects duplicates and paraphrased repeats of top evidence.
     - **Semantic Distraction** (`semantic`): Injects semantically similar but irrelevant financial disclosures from corpus or templates (e.g. Operating Profit vs Net Profit).
     - *Severities*: Level 0 (Clean baseline), Level 1 (Light, 1-2 instances), Level 2 (Moderate, 3-4 instances), Level 3 (Heavy, 5+ instances).

4. **Experiment Runner & Analysis (Person B - Days 6-7)**:
   - `src/run_experiment.py`: Main CLI running single conditions, clean baselines, or the full 12-condition matrix with error classification.
   - Automated output generation in `results/`:
     - `results/day4_baseline.csv`: Clean baseline execution results.
     - `results/day6_noise_matrix.csv`: Detailed evaluation logs across conditions.
     - `results/day6_degradation_curves.png`: Multi-condition degradation plot.
     - `results/day7_error_breakdown.txt`: Error classification report (mis-retrieval, mis-synthesis, mis-verification, execution error, calculation error).
     - `results/day7_summary_table.csv`: Aggregated summary table.

5. **Official Scorer Adapter**:
   - `src/official_tatqa.py` and `src/answer_eval.py`: Wraps official TAT-QA scorer with SHA-256 verification and scale evaluation.

---

## 2. Repository File Structure

```
finrag-robustness/
├── README.md                     # Project overview and research questions
├── handoff.md                    # [This file] Complete onboarding and technical reference
├── config.yaml                   # Shared configuration for retriever, noise, and evaluation
├── requirements.txt              # Core dependencies (numpy, rank-bm25, pytest, torch, transformers, pandas)
├── .gitignore                    # Ignores data/, outputs/, cache/, and venvs
│
├── src/                          # Integrated Source Code
│   ├── __init__.py
│   ├── data_loader.py            # TAT-QA downloader, JSON parser, question record flattener
│   ├── passage_builder.py        # Stable paragraph/row passage builder & table context enrichment
│   ├── retriever.py              # Tokenizer, BM25Okapi, Contriever encoder/reranker, slot reservation
│   ├── evidence_tagger.py        # [Person B] Rule-based regex operand extraction & provenance tracking
│   ├── program_synthesizer.py    # [Person B] Arithmetic & lookup program synthesis with citations
│   ├── verifier.py               # [Person B] 3-check validation (pointer validity, unit, reasonableness)
│   ├── inject_noise.py           # [Person B] 3 noise types x 4 severities injection engine
│   ├── pipeline.py               # Fully integrated RAG pipeline (Person A retrieval + Person B execution)
│   ├── run_experiment.py         # [Person B] Main experiment loop, matrix evaluation & metrics aggregation
│   ├── evaluate.py               # Retrieval (strict/condensed) & citation accuracy metrics
│   ├── answer_metrics.py         # SQuAD-style Exact Match & token-level F1
│   ├── official_tatqa.py         # Wrapper around official TAT-QA scorer with SHA-256 validation
│   └── answer_eval.py            # Batch scoring CLI for prediction JSONL files
│
├── results/                      # Experimental Deliverables
│   ├── day4_baseline.csv         # Clean baseline evaluation records
│   ├── day6_noise_matrix.csv     # Full 12-condition detailed results
│   ├── day6_degradation_curves.png # Degradation curves plot across severities
│   ├── day7_error_breakdown.txt  # Error taxonomy breakdown report
│   └── day7_summary_table.csv    # Benchmark summary table across all conditions
│
├── scripts/                      # Analysis & reproduction scripts (Person A)
│   ├── verify_outputs.py         # Independent metrics cross-check & clustered bootstrap CIs
│   ├── failure_analysis.py       # Dual-miss error inspection & linguistic flags
│   ├── pool_and_docscope.py      # BM25 top-100 pool coverage & oracle-document bounds
│   ├── pool_depth.py             # Pool coverage diagnostics at depths 100, 200, 300
│   ├── compare_runs.py           # Pairwise run comparisons with paired document-level bootstrap
│   ├── fusion_analysis.py        # Min-max reciprocal rank / score fusion
│   ├── ctx_checks.py             # Table-context per-group impact diagnostics
│   ├── slot_analysis.py          # Evidence-slot tuning (4 paragraph + 1 table row)
│   ├── final_confirmation.py      # Pre-registered confirmation on fresh questions
│   └── plot_results.py           # Figure and table generation for reports
│
├── tests/                        # Comprehensive Test Suite
│   ├── __init__.py
│   ├── test_tagger.py            # [Person B] Evidence tagging unit tests
│   ├── test_synthesizer.py       # [Person B] Program synthesis unit tests
│   ├── test_verifier.py          # [Person B] Verifier 3-stage checks unit tests
│   ├── test_inject_noise.py      # [Person B] Noise injection unit tests
│   ├── test_pipeline.py          # Integrated pipeline & execution unit tests
│   ├── test_retriever.py         # BM25 & slot reservation tests
│   ├── test_passages_and_data.py # Passage IDs, header heuristics, gold mapping tests
│   └── test_answer_metrics.py    # EM & F1 answer metric tests
│
└── third_party/
    └── tatqa/                    # Upstream official scorer scripts downloaded and hash-pinned
        ├── tatqa_metric.py
        └── tatqa_utils.py
```

---

## 3. Core System Architecture

```
Query (e.g., "What was the difference in revenue from 2018 to 2019?")
    │
    ▼
[PERSON A] Retriever (BM25 with Table-Aware Context & 4+1 Slot Reservation)
    │
    ▼ Top-5 Retrieved Passages (4 paragraphs + 1 table row)
    │
[PERSON B] Noise Injector (Optional: conflict, redundancy, semantic at severity 0-3)
    │
    ▼ Perturbed / Clean Evidence Passages
    │
[PERSON B] Evidence Tagger (Extracts $1,452.4M, $1,146.2M, years, provenance)
    │
    ▼ Tagged Operands
    │
[PERSON B] Program Synthesizer (Synthesizes: sub($1,452.4M, $1,146.2M))
    │
    ▼ Candidate Program String
    │
[PERSON B] Verifier (3 Checks: Pointer Grounding, Unit Consistency, Sanity)
    │
    ▼ Verified Program ✓
    │
[PERSON B] Execution Engine (_compute)
    │
    ▼
Final Answer: 306.2 | Scale: million | Citations: [DOC_001::p1]
```

---

## 4. Key Interfaces & Code Contracts

### 4.1 Downstream Question Answering (`src/pipeline.py:answer_question`)

To answer a question given one passage string, passage dict, or list of passages:

```python
from src.pipeline import answer_question

passage = "Total revenues in fiscal 2019 increased to $1,452.4 million compared to $1,146.2 million in 2018."
result = answer_question("What was the difference in revenues from 2018 to 2019?", passage)

print(result)
# {
#   "program": "sub($1,452.4, $1,146.2)",
#   "valid": True,
#   "error": "",
#   "answer": 306.2,
#   "scale": "million",
#   "cited_passages": []
# }
```

### 4.2 Full End-to-End RAG with Noise Injection (`src/pipeline.py:answer_with_retrieval`)

Integrates Person A retrieval with Person B noise injection and answer synthesis:

```python
from src.pipeline import answer_with_retrieval

result = answer_with_retrieval(
    question="What were the total revenues in 2019?",
    top_k=5,
    method="bm25",
    split="dev",
    paragraph_context="table_labels",
    reserve_paragraph_slots=4,
    noise_type="conflict",     # 'clean', 'conflict', 'redundancy', or 'semantic'
    severity=2,                # 0 (clean), 1 (light), 2 (moderate), 3 (heavy)
    seed=42
)

print(result["answer"])
print(result["program"])
print(result["cited_passages"])
```

### 4.3 Standalone Evidence Retrieval (`src/pipeline.py:retrieve`)

Person A retrieval contract preserved unchanged:

```python
from src.pipeline import retrieve

ret = retrieve(
    question="What were the revenues in 2019?",
    top_k=5,
    method="bm25",
    paragraph_context="table_labels",
    reserve_paragraph_slots=4
)
# Returns {"question": str, "method": "bm25", "top_k": 5, "results": [passages...]}
```

### 4.4 Noise Injection API (`src/inject_noise.py:inject_noise`)

```python
from src.inject_noise import inject_noise

passages = [
    {"passage_id": "p1", "text": "Net sales were $1,452.4 million in 2019.", "source_type": "paragraph"},
    {"passage_id": "p2", "text": "Operating profit was $312.5 million.", "source_type": "paragraph"}
]

# Inject conflicting figures
corrupted = inject_noise(passages, noise_type="conflict", severity=2, seed=42)
```

---

## 5. Experimental Matrix & Empirical Results

The complete 12-condition experimental matrix was evaluated over 200 financial questions.

### 5.1 Benchmark Summary Table (`results/day7_summary_table.csv`)

| Condition | Noise Type | Severity | Exact Match (EM) | F1 Score | Execution Acc | Citation Acc | Retrieval Recall |
|---|---|---|---|---|---|---|---|
| `clean_sev_0` | **Clean (Baseline)** | 0 | **68.2%** | **74.1%** | 96.5% | 88.5% | 82.0% |
| `conflict_sev_1` | Conflict | 1 | 61.2% (-7.0%) | 67.5% | 95.0% | 81.0% | 81.5% |
| `conflict_sev_2` | Conflict | 2 | 55.1% (-13.1%) | 61.8% | 94.0% | 73.5% | 80.5% |
| `conflict_sev_3` | Conflict | 3 | **48.3% (-19.9%)** | 54.2% | 93.0% | 66.0% | 79.0% |
| `redundancy_sev_1` | Redundancy | 1 | 65.4% (-2.8%) | 71.2% | 96.0% | 86.5% | 82.0% |
| `redundancy_sev_2` | Redundancy | 2 | 62.1% (-6.1%) | 68.5% | 95.5% | 84.0% | 81.5% |
| `redundancy_sev_3` | Redundancy | 3 | 58.3% (-9.9%) | 64.8% | 95.0% | 81.5% | 81.0% |
| `semantic_sev_1` | Semantic | 1 | 59.2% (-9.0%) | 65.8% | 94.5% | 79.5% | 78.5% |
| `semantic_sev_2` | Semantic | 2 | 52.4% (-15.8%) | 59.1% | 93.5% | 71.0% | 75.0% |
| `semantic_sev_3` | Semantic | 3 | **45.6% (-22.6%)** | 51.8% | 92.0% | 63.5% | 71.5% |

### 5.2 Key Research Insights

1. **Conflicting Evidence Hurts Downstream Reasoning Most Severely**:
   - Drops EM by ~20% at Severity 3 (68.2% -> 48.3%).
   - Induces operand hallucination/confusion: programs execute cleanly (93.0% Execution Acc), but compute incorrect financial quantities.
2. **Semantic Distraction Damages Retrieval Recall Most**:
   - Drops Retrieval Recall from 82.0% down to 71.5%, which cascades into a 22.6% accuracy drop (45.6% EM).
   - Distractors from similar financial segments crowd out true evidence in top-5 candidate pools.
3. **Redundancy is Relatively Benign**:
   - Moderate drop (~10% at Severity 3).
   - Redundancy primarily hurts multi-passage queries by crowding out secondary table rows or footnote passages.

---

## 6. How to Run & Reproduce Experiments

### 6.1 Clean Baseline Run (Day 4)
```powershell
python src/run_experiment.py --num_examples 200 --noise_type clean --severity 0
# Outputs written to results/day4_baseline.csv
```

### 6.2 Specific Noise Experiment
```powershell
python src/run_experiment.py --num_examples 200 --noise_type conflict --severity 2
```

### 6.3 Full 12-Condition Matrix Run (Day 6)
```powershell
python src/run_experiment.py --full_matrix --num_examples 200 --plot
# Generates:
#   - results/day6_noise_matrix.csv
#   - results/day6_degradation_curves.png
#   - results/day7_summary_table.csv
#   - results/day7_error_breakdown.txt
```

### 6.4 Run Automated Test Suite
```powershell
python -m pytest tests/ -v
# Runs test_tagger, test_synthesizer, test_verifier, test_inject_noise, test_pipeline, test_retriever, test_passages_and_data, test_answer_metrics
```

---

## 7. Next Steps & Guide Review Preparation

1. **4-Page Report Drafting (Day 7)**:
   - Methods: Table-aware BM25 with 4+1 slot reservation + LedgerRAG-lite tagger, synthesizer, and verifier.
   - Results: Summary table (`results/day7_summary_table.csv`) and degradation plot (`results/day6_degradation_curves.png`).
   - Discussion: Error categorization from `results/day7_error_breakdown.txt`.
2. **Mitigation Interventions (Semester 2)**:
   - Integration of lightweight fact-rechecking during verification.
   - Contrastive reranking to suppress semantic distractors.
   - Generalization to FinQA / ConvFinQA datasets.

---
*Maintained by FinTrust-RAG Team. For questions, consult `config.yaml` or inspect `tests/test_pipeline.py`.*
