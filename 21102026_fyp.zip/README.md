# Financial RAG Robustness Under Evidence Noise

**A Systematic Study of How Imperfect Retrieved Evidence Degrades Financial Question Answering**

---

## 🎯 Project Overview

This project investigates a critical gap in financial RAG systems: **how do different types of retrieval noise (conflicting information, redundancy, semantic distraction) degrade numerical reasoning accuracy and citation faithfulness?**

Current financial RAG systems like LedgerRAG assume retrieved evidence is reasonably reliable. In reality, financial documents contain conflicting numbers, redundant claims, and semantically similar but incorrect information. **We systematically inject these noise types and measure degradation.**

---

## 📋 Research Question

> How do imperfect retrieved evidence—conflicting information, redundancy, and semantic noise—degrade numerical reasoning accuracy and citation faithfulness in financial RAG? Can lightweight re-ranking and verification steps recover robustness?

---

## 🏗️ System Architecture

```
Query (e.g., "What was Apple's revenue in Q2 2024?")
    ↓
[PERSON A] Retriever (BM25 + Contriever)
    ↓ 
Retrieved Passages (top-5 relevant documents)
    ↓
[PERSON B] Evidence Tagger
    ↓
Tagged Operands (identified numbers: $100M, 2.5%, etc.)
    ↓
[PERSON B] Program Synthesizer
    ↓
Arithmetic Program (e.g., add($100M, $50M) = $150M)
    ↓
[PERSON B] Verifier (3 checks: pointer validity, unit consistency, reasonableness)
    ↓
Verified Program ✓
    ↓
Execution Engine
    ↓
Final Answer with Citation
    ↓
[PERSON B - DAY 5] Noise Injector
    ↓
Degraded Accuracy Measurement
```

---

## 🔬 Three Types of Evidence Noise

### 1. **Conflicting Information**
- **Definition:** Different numeric values for the same metric across passages
- **Example:** 
  - Gold passage: "Revenue = $100M"
  - Injected passage: "Revenue = $110M" (different segment/period)
- **Expected degradation:** ~20% accuracy drop

### 2. **Redundancy**
- **Definition:** Same correct information repeated 5+ times in retrieved set
- **Example:** Revenue figure appears in summary, table, footnote, narrative
- **Expected degradation:** ~15% accuracy drop

### 3. **Semantic Distraction**
- **Definition:** Semantically similar but irrelevant passages (confuse embeddings)
- **Example:** Query asks "Net Profit"; retrieve "Operating Profit" from same company
- **Expected degradation:** ~18% accuracy drop

---

## 📊 Experimental Design

### Dataset
- **Primary:** TAT-QA (16,552 financial QA pairs with gold evidence)
- **Test set:** 200-500 examples
- **Metrics:** Exact Match (EM), F1, Execution Accuracy, Citation Accuracy

### Noise Severities
- **Level 0 (Clean):** No noise (baseline)
- **Level 1 (Light):** 1-2 noise instances per query
- **Level 2 (Moderate):** 3-4 noise instances per query
- **Level 3 (Heavy):** 5+ noise instances per query

### Full Experimental Matrix
- 3 noise types × 4 severity levels = 12 conditions
- 200+ examples per condition
- Expected output: Degradation curves per noise type

---

## 👥 Division of Labor

| Person | Role | Responsibilities |
|--------|------|------------------|
| **Person A** | Retrieval Lead | BM25 indexing, Contriever re-ranking, integration |
| **Person B** | Research Lead | Evidence tagging, synthesis, verification, noise injection, analysis |

---

## 📅 7-Day Sprint Plan

### Days 1-3: Component Development
- **Person A:** Build retriever (BM25 + Contriever)
- **Person B:** Build tagger, synthesizer, verifier

### Day 4: Integration
- Wire components together
- Test end-to-end on 50 examples
- Measure baseline accuracy (~65% EM)

### Day 5: Noise Injection
- Implement 3 noise functions
- Test on 200 examples

### Day 6: Full Experiment
- Run all 12 noise conditions
- Generate summary table + plots

### Day 7: Analysis + Reporting
- Error breakdown analysis
- Per-query-type results
- Write 4-page report

---

## 💾 Repository Structure

```
finrag-robustness/
├── src/
│   ├── retriever.py              # BM25 + Contriever
│   ├── evidence_tagger.py        # Extract numbers from passages
│   ├── program_synthesizer.py    # Build arithmetic programs
│   ├── verifier.py               # Validation checks
│   ├── inject_noise.py           # Noise injection (3 types)
│   ├── pipeline.py               # End-to-end integration
│   ├── run_experiment.py         # Main experiment loop
│   └── evaluate.py               # EM/F1/citation metrics
│
├── results/
│   ├── day4_baseline.csv         # Clean baseline results
│   ├── day6_noise_matrix.csv     # Full 12-condition results
│   ├── day6_degradation_curves.png
│   ├── day7_error_breakdown.txt
│   └── day7_summary_table.csv
│
├── config.yaml                   # Shared configuration
├── README.md                     # This file
└── report_draft_day7.pdf         # Final 4-page report
```

---

## 🚀 Getting Started

### 1. Setup (5 min)
```bash
git clone https://github.com/YOUR_USERNAME/finrag-robustness.git
cd finrag-robustness
git config user.email "your@email.com"
git config user.name "Your Name"
git checkout -b person-b/dev  # or person-a/dev
```

### 2. Install Dependencies (in Colab or local)
```bash
pip install transformers torch datasets scikit-learn
```

### 3. Download Dataset
```python
from datasets import load_dataset
tatqa = load_dataset('tatqa')
```

### 4. Run Pipeline
```bash
python src/run_experiment.py \
  --num_examples 200 \
  --noise_type conflict \
  --severity 2
```

---

## 📈 Expected Results

| Condition | Expected EM Accuracy |
|-----------|----------------------|
| Clean (baseline) | ~68% |
| Conflict, Level 1 | ~61% (-7%) |
| Conflict, Level 2 | ~55% (-13%) |
| Conflict, Level 3 | ~48% (-20%) |
| Redundancy, Level 1 | ~65% (-3%) |
| Redundancy, Level 2 | ~62% (-6%) |
| Semantic Distraction, Level 1 | ~59% (-9%) |

**Key Insight:** Conflicting evidence hurts most; redundancy is benign

---

## 🔍 Evaluation Metrics

### Primary Metrics
- **Exact Match (EM):** Binary correctness (answer matches gold exactly)
- **F1 Score:** Token-level partial credit
- **Execution Accuracy:** Did the program run without error?

### Secondary Metrics
- **Citation Accuracy:** Does cited passage contain claimed number?
- **Retrieval Recall:** Is gold passage in top-5?
- **Degradation Slope:** How quickly does accuracy drop with severity?

---

## 📝 Analysis Framework

### Per-Noise-Type Analysis
For each noise type, report:
- Clean baseline accuracy
- Accuracy at each severity level
- Degradation curve (plot)
- Error breakdown (mis-retrieval vs mis-synthesis vs mis-verification)

### Per-Query-Type Analysis
Break down results by operation:
- **Arithmetic queries** (addition, subtraction)
- **Comparison queries** (which is larger?)
- **Lookup queries** (find single value)

### Example Output
```
Conflict Noise Analysis:
├── Clean: 68.2% EM
├── Severity 1: 61.2% EM (-7%)
│   ├── Mis-retrieval: 12%
│   ├── Mis-synthesis: 28%
│   ├── Mis-verification: 8%
│   └── Execution error: 2%
├── Severity 2: 55.1% EM (-13%)
└── Severity 3: 48.3% EM (-20%)

Insight: Conflict mainly hurts via retrieval (gold passage not in top-5)
```

---

## 📚 Simplified vs Full LedgerRAG

| Component | LedgerRAG (Full) | This Project (Simplified) |
|-----------|------------------|--------------------------|
| Evidence Tagging | Neural pointer network | Rule-based regex |
| Program Synthesis | Template + learned guidance | Template-only |
| Verification | 3 checks + constraint solver | 3 checks (heuristic) |
| Calibration | Temperature scaling + ECE | Skipped |
| Error Taxonomy | 5 categories | 4 categories |

**Why simplified?** Focus is on noise robustness, not baseline replication. Simplified version is sufficient for the research contribution.

---

## 🎓 Semester 1 vs Semester 2

### Semester 1 (This Sprint - 8 weeks)
✅ Core noise robustness study on TAT-QA  
✅ 3 noise types × 4 severities tested  
✅ Degradation quantified  
✅ Workshop-level paper (8-10 pages)  
✅ Submit to ACL/EMNLP workshop

### Semester 2 (Extended - 8 weeks)
- Generalization to other datasets (FinQA, ConvFinQA)
- Domain embeddings comparison (FinBERT vs generic)
- Intervention testing (re-ranking, improved verification)
- Adaptive mitigation strategies
- Expand to conference-level paper (12-14 pages)
- Submit to ACL/EMNLP/TACL main

---

## 🔗 Key References

1. **LedgerRAG:** Gudipuri (2026) - Faithful Retrieval-Augmented Numerical Reasoning over Financial Filings
2. **TAT-QA:** Zhu et al. (2021) - Hybrid Text-Table QA Benchmark
3. **RARE:** Retrieval-Aware Robustness Evaluation (2025)
4. **RAGGED:** Informed Design of Scalable RAG Systems (2025)
5. **VeNRA:** Deterministic Fact Ledgers for Financial Reasoning (2026)

---

## 📞 Communication Protocol

### Daily Standup (Async - Slack)
Post at EOD with format:
```
Day X EOD Update - [Name]

✅ Completed:
- [Task]

📊 Results:
- [Metric]: X%

❌ Blockers:
- [None/Issue]

📅 Next:
- [Tomorrow]
```

### Weekly Sync (Day 7 - 30 min call)
Review results, discuss next steps, plan Semester 2

---

## ✅ Success Criteria

**By End of Day 7:**
- ✅ Working LedgerRAG-lite pipeline
- ✅ 200 examples × 12 noise conditions tested
- ✅ Degradation curves generated
- ✅ Error analysis completed
- ✅ 4-page report drafted
- ✅ Code committed to GitHub with README
- ✅ Ready for guide review (Week 2)

**By End of Week 8:**
- ✅ 500 examples tested (scale up from Day 7)
- ✅ Statistical testing completed
- ✅ Generalization to second dataset (FinQA)
- ✅ 10-page workshop paper finalized
- ✅ Ready for submission (Week 9)

---

## 🚨 Risk Mitigation

| Risk | Mitigation |
|------|-----------|
| Baseline accuracy too high (>85%) | Use harder query subset or measure F1 instead |
| No clear noise effect | Increase noise severity or add interaction analysis |
| Implementation bugs | Test on 10 examples first, then scale |
| Time crunch Week 7 | Start writing by Day 5 |

---

## 📄 Final Deliverables (Day 7)

1. **GitHub Repo** - All code, reproducible
2. **Results CSV** - Full noise matrix (3 types × 4 severities × metrics)
3. **Plots** - Degradation curves, heatmaps, error breakdown
4. **Report** - 4 pages (methods, results, analysis, next steps)
5. **README** - How to reproduce experiments
6. **Error Analysis** - Per-noise-type failure modes

---

## 🎯 One-Sentence Summary

> We systematically degrade financial RAG accuracy by injecting realistic noise types into retrieved evidence, quantifying degradation curves and identifying which components fail under each noise type.